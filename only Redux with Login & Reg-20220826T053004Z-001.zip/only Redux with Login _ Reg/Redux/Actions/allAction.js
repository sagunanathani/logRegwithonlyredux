export const Logier = (data) => {
    return {
        type: "LOGIER",
        payload: data
    }
};
export const Registrations = (data) => {
    return {
        type: "REGISTRATIONS",
        payload: data
    }
};
export const Foften = (data) => {
    return {
        type: "FORGOT",
        payload: data
    }
};